
<?php

$xml = simplexml_load_file("xml/cd.xml") or die("Error: Cannot create object");

echo "<pre>";
print_r($xml);
echo "</pre>";

//echo $xml->to;

foreach ($xml as $field => $content)
    echo "<br/>" . $field . "-" . $content . "<br/>";

?>

