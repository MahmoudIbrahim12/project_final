<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo "PHP Page"; ?></title>
</head>

<body>

    <?php
    $x = (int)9.5;
    $x = (int)9.5;
    $x = (bool)0;
    //echo $x;
    var_dump($x);
    echo "<br>";
    var_export($x);
    echo "<br>";
    echo gettype($x);

    echo "<br>";
    $x_int = 55;
    $x_string = strval($x_int);
    var_dump($x_string);

    echo "<br>";

    var_dump(boolval(1)); //true
    echo "<br>";
    var_dump(boolval(0)); //false
    echo "<br>";
    var_dump(boolval(-1.2)); //true
    echo "<br>";
    var_dump(boolval("")); //false
    echo "<br>";
    var_dump(boolval("sdf")); //true

    echo "<br>";

    $b  = false;
    echo $b; //blank
    echo "<br>";
    var_dump($b);
    echo "<br>";
    //$b = (object)$b;
    $b = (array)$b;
    var_dump($b);

    echo "<br>";
    $n = null;
    var_dump($n);

    ?>
</body>

</html>