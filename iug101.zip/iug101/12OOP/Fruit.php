<?php

// class Fruit
// {
//     public $name;
//     public $color;

//     function set_name($name)
//     {
//         $this->name = $name;
//     }

//     function get_name()
//     {
//         return $this->name;
//     }
// }


// // $f1 = new fruit();
// $f1->set_name("Apple");
// echo $f1->get_name();
// echo "<br>";
// var_dump($f1);
// echo "<br>";
// var_dump($f1 instanceof fruit);
