<?php

class Fruit
{
    public $name;
    public $color;

    function __construct($name, $color)
    {
        $this->name = $name;
        $this->color = $color;
    }

    function intro()
    {
        echo "<h2>{$this->name} : {$this->color}</h2>";
    }
}

class Apple extends Fruit
{
    public $weight;

    function __construct($name, $color, $weight)
    {
        parent::__construct($name, $color);
        $this->weight = $weight;
    }

    function intro()
    {
        echo "<h2>{$this->name} : {$this->color} : {$this->weight}</h2>";
    }
}

$apple = new Apple("Apple1", "RED", "65");
$apple->intro();
