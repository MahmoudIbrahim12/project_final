<?php
class Student
{
    private $id;
    private $name;
    private $average;

    function __construct($id, $name, $average)
    {
        $this->id = $id;
        $this->name = $name;
        $this->average = $average;
    }

    function display()
    {
        echo "<h3>{$this->id} : {$this->name} : {$this->average}</h3>";
    }

    function __destruct()
    {
        echo "<h3>{$this->id} : {$this->name} : {$this->average}</h3>";
    }
}

// $s1 = new Student;
// $s1 = new Student();
// $s1->name = "Ahmad";
// echo $s1->name;

$s2 = new Student(1, "Ahmad", 90);
// var_dump($s2);
// $s2->display();
