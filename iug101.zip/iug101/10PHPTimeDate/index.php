<?php

date_default_timezone_set("Asia/Gaza");

echo "&copy;" . " 2019 - ", date("Y"), "<br>";
echo date("D / M / y"), "<br>";
echo date("h : i : s a"), "<br>";
