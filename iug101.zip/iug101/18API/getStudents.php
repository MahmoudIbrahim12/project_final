<?php

header("Content-Type:application/json; charset=utf-8");
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "iug101";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error)
    die("Connection Failed" . $conn->connect_error);
else {

    $sql = "select * from student";
    $result = $conn->query($sql);

    $students = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            array_push($students, $row);
        }
        echo json_encode($students);
    }

    $conn->close();
}
