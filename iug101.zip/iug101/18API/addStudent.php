<?php

require_once '../11PHPMySQL/config.php';

if ($conn->connect_error)
    die("Connection Failed" . $conn->connect_error);
else {
    if ($_SERVER['REQUEST_METHOD'] === "POST") {
        $name = $_POST['txtName'];
        $email = $_POST['txtEmail'];
        $average = $_POST['txtAverage'];

        $obj = new stdClass;

        if (!empty($name) && !empty($email) && !empty($average)) {
            $sql = "insert into student(name,email,average)
                values('$name','$email',$average)";

            if ($conn->query($sql) === True) {
                $obj->status = true;
                $obj->message = "Added Successfully";
            } else {
                $obj->status = false;
                $obj->message = "Error in Add";
            }
        } else {
            $obj->status = false;
            $obj->message = "Please Fill Fields";
        }
        echo json_encode($obj);
    }
}
