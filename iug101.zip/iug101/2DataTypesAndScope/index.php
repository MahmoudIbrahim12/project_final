<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <h2>PHP Page</h2>
    <?php

    $x = 0;
    $txt = "Hello PHP";
    $f = 9.4;

    //echo $x . "<br>";
    var_dump($x);
    var_export($x);
    //echo "<br>";
    //echo $txt;
    var_dump($txt);

    var_export($txt);

    var_dump(floatval($x));
    var_dump(intval($f));
    var_dump(boolval($x));
    ?>

</body>

</html>