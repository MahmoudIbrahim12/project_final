<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php
    $x = 5;
    $y = 10;

    //$x = "Ahmad";
    //echo $x;

    function myTest()
    {
        //global $x, $y;
        // $y = $x + $y;

        //or using Superglobal variable

        $GLOBALS['y'] =  $GLOBALS['x'] +  $GLOBALS['y'];
    }

    myTest();
    echo $y;
    ?>
</body>

</html>