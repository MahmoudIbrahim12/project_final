<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "iug101";


// $conn = mysqli_connect($servername, $username, $password, $dbname);

// if (!$conn)
//     die("Connection Failed" . mysqli_connect_error());
// else
//     echo "Connection Successfully";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error)
    die("Connection Failed" . $conn->connect_error);
else {
    echo "Connection Successfully";
}
