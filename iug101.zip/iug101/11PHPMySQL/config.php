<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "iug101";

$conn = new mysqli($servername, $username, $password, $dbname);

function sum($x, $y)
{
    return $x + $y;
}
