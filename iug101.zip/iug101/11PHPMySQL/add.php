<?php

//include - require
require_once 'config.php';
require_once 'config.php';

if ($conn->connect_error)
    die("Connection Failed" . $conn->connect_error);
else {
    if ($_SERVER['REQUEST_METHOD'] === "POST") {
        if (isset($_POST['btnAdd'])) {
            $name = $_POST['txtName'];
            $email = $_POST['txtEmail'];
            $average = $_POST['txtAverage'];
            if (!empty($name) && !empty($email) && !empty($average)) {
                $sql = "insert into student(name,email,average)
                values('$name','$email',$average)";

                if ($conn->query($sql) === True) {
                    $lastid = $conn->insert_id;
                    echo "Student added Successfully " . $lastid . "<br>";
                } else
                    echo "Error " . $sql . " : " . $conn->error;
            } else
                echo "Please Fill Fields";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <form method="POST" action="<?= $_SERVER['PHP_SELF']; ?>">
        Name : <input type="text" name="txtName" id="txtName">
        <br>
        Email : <input type="email" name="txtEmail" id="txtEmail">
        <br>
        Average : <input type="number" name="txtAverage" id="txtAverage">
        <br>
        <input type="submit" value="Add Student" name="btnAdd">
    </form>
    <a href="get.php">Get All Students</a>
</body>

</html>