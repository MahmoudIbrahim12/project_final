<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "iug101";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error)
    die("Connection Failed" . $conn->connect_error);
else {

    $sql = "select * from student";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table border=1>";
        echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Average</th><th>Delete</th><th>Update</th></tr>";
        while ($row = $result->fetch_assoc()) {
            //echo $row['id'] . " : " . $row['name']  . " : " . $row['email'] . " : " . $row['average'] . "<br>";
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['name'] . "</td>";
            echo "<td>" . $row['email'] . "</td>";
            echo "<td>" . $row['average'] . "</td>";
            echo "<td><a href =delete.php?id=" . $row['id'] . ">Delete</a></td>";
            echo "<td><a href =update.php?id=" . $row['id'] . ">Update</a></td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No Data !";
    }

    $conn->close();
}
