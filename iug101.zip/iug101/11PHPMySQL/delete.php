<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "iug101";

if (isset($_GET['id'])) {
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error)
        die("Connection Failed" . $conn->connect_error);
    else {

        $student_id = $_GET['id'];
        $sql = "delete from student where id = " . $student_id;

        if ($conn->query($sql) === TRUE) {
            header('Location: get.php');
            exit();
        } else
            echo "Delete Error" . $sql . " : " . $conn->error;
    }
}
