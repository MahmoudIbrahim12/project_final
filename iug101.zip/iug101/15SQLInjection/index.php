<?php

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    if (isset($_POST['btnLogin'])) {
        // echo $_POST['txtUsername'];
        // echo "<br>";
        // echo $_POST['txtPassword'];
        // echo "<br>";
        // echo htmlspecialchars($_POST['txtUsername']);
        // echo "<br>";
        // echo stripslashes($_POST['txtUsername']);
        // echo "<br>";

        echo test_input($_POST['txtUsername']);
    }
}

function test_input($data)
{
    $data = trim($data); //remove spaces
    $data = stripslashes($data); //remove back-slash
    $data = htmlspecialchars($data); // dealing with data as string
    return $data;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Login</title>
</head>

<body>
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
        Username : <input type="text" name="txtUsername" id="txtUsername">
        <br>
        Password : <input type="password" name="txtPassword" id="txtPassword">
        <br>
        <input type="submit" value="Login" name="btnLogin">
    </form>
</body>

</html>