<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php

    //constants automatically global
    define("XY", "Hello PHP!", false);

    echo XY;
    echo "<br>";

    function myTest()
    {
        define("YY", "Welcome PHP!", false);
    }

    myTest();
    echo YY;
    ?>
</body>

</html>