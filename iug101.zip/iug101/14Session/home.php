<?php
session_start();
if (isset($_SESSION['txtUsername']) && isset($_SESSION['txtPassword'])) {
    echo $_SESSION['txtUsername'];
    echo "<br>";
    echo $_SESSION['txtPassword'];
    echo "<br>";
    echo "<pre>";
    print_r($_SESSION);
    echo "</pre>";
    echo "<a href = 'logout.php'>Logout</a>";
} else {
    header("Location:login.php");
    exit();
}
