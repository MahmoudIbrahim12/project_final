<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    if (isset($_POST['btnLogin'])) {
        $_SESSION['txtUsername'] = $_POST['txtUsername'];
        $_SESSION['txtPassword'] = $_POST['txtPassword'];
        header("Location:home.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Login</title>
</head>

<body>
    <form action="" method="post">
        Username : <input type="text" name="txtUsername" id="txtUsername">
        <br>
        Password : <input type="password" name="txtPassword" id="txtPassword">
        <br>
        <input type="submit" value="Login" name="btnLogin">
    </form>
</body>

</html>