<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <h1>PHP Page</h1>

    <?php

    $txt = "Ahmad";
    $x = 5;
    $y = 6;
    echo "Welcome to PHP! <br>";
    echo "<br>";
    echo $x + $y;
    echo "<br>";
    echo $txt . $x;
    echo "<br>";
    echo "X = $x";
    echo "<br>";
    echo 'X = $x';
    ?>
</body>

</html>