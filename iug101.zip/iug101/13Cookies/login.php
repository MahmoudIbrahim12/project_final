<?php
//setcookie("user", "ahmad", time() + 3600, "/");

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    if (isset($_POST['btnLogin'])) {
        setcookie("txtUsername", $_POST['txtUsername'], time() + 3600, "/");
        setcookie("txtPassword", $_POST['txtPassword'], time() + 3600, "/");
        header("Location:home.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <form method="POST" action="">
        Username : <input type="text" name="txtUsername" />
        <br>
        Password : <input type="password" name="txtPassword" />
        <br>
        <input type="submit" value="Login" name="btnLogin">
    </form>

    <?php

    echo "<pre>";
    print_r($_COOKIE);
    echo "</pre>";

    echo count($_COOKIE);

    ?>
</body>

</html>