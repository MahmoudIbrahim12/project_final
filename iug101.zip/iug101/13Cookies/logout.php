<?php
setcookie("txtUsername", "", time() - 3600, "/");
setcookie("txtPassword", "", time() - 3600, "/");
header("Location:login.php");
exit();
