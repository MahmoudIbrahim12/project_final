<?php
if (count($_COOKIE) > 0) {
    echo $_COOKIE['txtUsername'];
    echo "<br>";
    echo $_COOKIE['txtPassword'];
    echo "<br>";
    echo "<a href='logout.php'>Logout</a>";
}
