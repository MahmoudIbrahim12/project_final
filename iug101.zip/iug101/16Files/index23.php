<?php

//1- Read Files
// echo readfile("data.txt");

// $myfile = fopen("data.txt", "r") or die("Error");
// // echo fread($myfile, filesize("data.txt"));
// // echo fgets($myfile);
// // echo "<br>";
// // echo fgets($myfile);
// while (!feof($myfile)) {
//     echo fgets($myfile);
//     //echo fgetc($myfile);
//     echo "<br>";
// }
// fclose($myfile);

//------------------------------------------------
//2- Write to Files

$myfile = fopen("newfile.txt", "w") or die("Error File");
fwrite($myfile, "Welcome to PHP Files3");
fclose($myfile);
