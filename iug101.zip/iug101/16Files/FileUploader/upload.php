<?php
echo "<pre>";
print_r($_FILES);
echo "</pre>";

echo "<br>";

echo $_FILES['fileUpload']['name'];
echo "<br>";
echo $_FILES['fileUpload']['type'];
echo "<br>";
echo $_FILES['fileUpload']['size'];
echo "<br>";

$check = getimagesize($_FILES['fileUpload']['tmp_name']);

echo "<pre>";
print_r($check);
echo "</pre>";
