<?php

echo "<pre>";
print_r($_SERVER);
echo "</pre>";

//sensitive-case of key
echo $_SERVER['pHP_SELF']; //error //undefined index
echo $_SERVER['PHP_SELF'];
