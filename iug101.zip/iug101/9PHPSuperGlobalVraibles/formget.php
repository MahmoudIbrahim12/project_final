<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <form method="GET" action="<?php echo $_SERVER['PHP_SELF'] ?>">
        Message: <input type="text" name="txtMsg" />
        <input type="submit" value="Print" />
    </form>

    <?php

    if (isset($_GET['txtMsg'])) {
        if (!empty(trim($_GET['txtMsg']))) {
            echo $_GET['txtMsg'];
        } else
            echo "<h3 style='color:red';>Fill Data</h3>";
    }

    ?>
</body>

</html>