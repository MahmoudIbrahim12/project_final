<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php

    if ($_SERVER['REQUEST_METHOD'] === "POST") {
        if (isset($_POST['btnRegister'])) {
            if (!empty($_POST['txtName'])) {
                echo "<pre>";
                print_r($_POST);
                echo "</pre>";

                foreach ($_POST['cbHobbies'] as $key => $item) {
                    echo "$item <br>";
                }
            } else
                echo "Please Fill Fields";
        }
    }

    ?>


    <form action="<?= $_SERVER['PHP_SELF']; ?>" method="post">

        <label for="txtName"> Name :</label>
        <input type="text" name="txtName" id="txtName">
        <br>
        <label for=""> Gender :</label>
        <input type="radio" value="Male" name="rbGender" id="rbMale" checked><label for="rbMale"> Male</label>
        <input type="radio" value="Female" name="rbGender" id="rbFemale"><label for="rbFemale"> Female</label>
        <br>
        <label for="">Hobbies:</label>
        <br>
        <input type="checkbox" value="Reading" name="cbHobbies[]" id="cbReading"> <label for="cbReading">Reading</label>
        <br>
        <input type="checkbox" value="Programming" name="cbHobbies[]" id="cbProgramming"> <label for="cbProgramming">Programming</label>
        <br>
        <input type="checkbox" value="Writing" name="cbHobbies[]" id="cbWriting"> <label for="cbWriting">Writing</label>
        <br>
        <input type="submit" value="Register" name="btnRegister">
    </form>
</body>

</html>