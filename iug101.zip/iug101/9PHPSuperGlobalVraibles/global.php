<?php

$x = 43;
$y = 42;


echo "<pre>";
print_r($GLOBALS);
echo "</pre>";
