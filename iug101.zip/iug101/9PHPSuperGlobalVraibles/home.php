<?php

echo "<pre>";
print_r($_GET);
echo "</pre>";


if (isset($_GET['id']) && isset($_GET['name'])) {
    echo $_GET['id'] . "<br>";
    echo $_GET['name'] . "<br>";
    echo $_SERVER['QUERY_STRING'];
} else
    echo "Invalid Data";


    