<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form method="POST" action="<?= $_SERVER['PHP_SELF']; ?>">
        Username: <input type="text" name="txtUsername" />
        <br>
        Password: <input type="password" name="txtPassword" />
        <br>
        <input type="submit" value="Login" name="btnLogin" />
    </form>


    <?php

    // echo "<pre>";
    // print_r($_POST);
    // echo "</pre>";

    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        if (isset($_POST['txtUsername']) && isset($_POST['txtPassword'])) {
            echo $_POST['txtUsername'] . "<br>";
            echo $_POST['txtPassword'] . "<br>";
        } else
            echo "Fill Data";
    }
    ?>
</body>

</html>