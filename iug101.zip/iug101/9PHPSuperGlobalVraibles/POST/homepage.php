<?php

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";


    echo $_POST['txtUsername'] . "<br>";
    echo $_POST['txtPassword'] . "<br>";
} else
    echo "<h3 style='color:red;'>Sorry, you cannot browse this page</h3>";
