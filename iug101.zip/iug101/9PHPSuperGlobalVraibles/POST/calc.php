<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        if (isset($_POST['btnCalc'])) {
            $result = 0;
            $x = $_POST['txtFirst'];
            $y = $_POST['txtSecond'];
            $op = $_POST['ddlOperator'];
            if (empty($x) || empty($y)) {
                echo "Please fill fields";
            } else {
                $str = "";
                switch ($op) {
                    case "+":
                        $result = $x + $y;
                        break;
                    case "-":
                        $result = $x - $y;
                        break;
                    case "*":
                        $result = $x * $y;
                        break;
                    case "/":
                        $result = $x / $y;
                        break;
                }
            }
        }
    }
    ?>

    <form method="POST" action="<?= $_SERVER['PHP_SELF']; ?>">
        First Number : <input type="number" name="txtFirst" value="<?= $x; ?>" />
        <br>
        Second Number : <input type="number" name="txtSecond" value="<?= $y; ?>" />
        <br>
        Choose Operator:
        <select name="ddlOperator">
            <option value="+">Sum</option>
            <option value="-">Sub</option>
            <option value="/">Div</option>
            <option value="*">Multi</option>
        </select>
        <br>
        The Result : <input type="number" name="txtResult" value="<?= $result; ?>" disabled />
        <br>
        <input type="submit" value="Calc" name="btnCalc" />
    </form>


</body>

</html>