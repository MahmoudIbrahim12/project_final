<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php

    $data = array(1, 2, 3, "Ahmad", true);
    $data[0] = 43;
    $data[7] = "43";

    echo "Size of Array : " . count($data) . "<br>";

    // for ($i = 0; $i < count($data); $i++) {

    //     echo $data[$i] . "<br>";
    // }


    echo "<ul>";

    foreach ($data as $value) {
        echo "<li>$value</li>";
    }

    echo "</ul>";


    // echo "<pre>";
    // print_r($data);
    // echo "</pre>";

    ?>
</body>

</html>