<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    $data = array(23, 4, 5, 6, 43, 2);

    //array_push($data, 22, 33, 44, 55);
    //array_unshift($data, 22, 33, 44, 55);

    // $result = array_pop($data);
    //$result = array_shift($data);
    //echo " $result <br>";

    //echo $data[2] . " have been deleted";

    // unset($data[2]);

    var_dump(array_search(5, $data, true));
    var_dump(in_array(5, $data, true));

    echo "<pre>";
    print_r($data);
    echo "</pre>";

    ?>
</body>

</html>