<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php


    $data = array(
        array("Ahmad", 35, 90),
        array("Ali", 43, 67),
        array("Mohammad", 21, 78),
        array("Alaa", 23, 88)
    );


    // echo "<pre>";
    // print_r($data[0]);
    // echo "</pre>";



    for ($row = 0; $row < 4; $row++) {
        echo "Row : $row";
        echo "<ul>";
        for ($col = 0; $col < 3; $col++) {
            echo "<li>" . $data[$row][$col] . "</li>";
        }
        echo "</ul>";
    }

    echo "<table>";
    for ($row = 0; $row < 4; $row++) {
        echo "<tr>";
        for ($col = 0; $col < 3; $col++) {
            echo "<td>" . $data[$row][$col] . "</td>";
        }
        echo "</tr>";
    }

    echo "</table>";
    ?>
</body>

</html>