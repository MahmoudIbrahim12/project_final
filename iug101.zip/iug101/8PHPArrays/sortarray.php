<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php

    $data = array(43, 55, 546, 32, 1);

    //sort($data);
    //rsort($data);
    //asort($data);

    // echo "<pre>";
    // print_r($data);
    // echo "</pre>";


    //====================================

    $data2 = array("c" => "car", "a" => "ahmad", "b" => "bilal", "v" => "abdullah", 32 => "AA", 54 => 23);

    //ksort($data2);
    //krsort($data2);
    arsort($data2);

    echo "<pre>";
    print_r($data2);
    echo "</pre>";

    ?>

</body>

</html>