<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php


    // $diet = array(
    //     array("A", "B", "C"),
    //     array("A", "BBB", "C"),
    //     array("AA", "BB"),
    //     array("AA", "BB", "CC", array(1, 2, 3)),
    //     array("A1", "B1", array("hzm" => 54)),
    // );


    // echo "<pre>";
    // print_r($diet);
    // echo "</pre>";


    // echo $diet[4][2]["hzm"] . "<br>";
    // echo $diet[3][3][2] . "<br>";


    $countries = array(
        "Group1" => array("PAL", "EGYPT", "SYRIA"),
        "Group2" => array("USA", "UK", "PRC"),
        "Group3" => array("Tunsia", "KSA", "UAE")
    );

    echo "<pre>";
    print_r($countries);
    echo "</pre>";

    echo $countries["Group1"][2];


    foreach ($countries as $key => $value) {
        echo "<h3>$key</h3>";
        echo "<ul>";
        foreach ($value as $val) {
            echo "<li>$val</li>";
        }
        echo "</ul>";
    }



    ?>
</body>

</html>