<?php

$data = file_get_contents("json/person_array.json");
$data = json_decode($data);

echo "<pre>";
print_r($data);
echo "</pre>";

for ($i = 0; $i < count($data); $i++) {
    echo $data[$i]->name . "<br>";
    echo $data[$i]->email . "<br>";

    foreach ($data[$i]->phone as $key => $value) {
        echo $key . "<br>";
        echo $value . "<br>";
    }

    // echo $data[0]->phone->home . "<br>";
    // echo $data[0]->phone->mobile . "<br>";
}
