<?php

$data = file_get_contents("json/person_object.json");
$data = json_decode($data);

echo "<pre>";
print_r($data);
echo "</pre>";

echo $data->name . "<br>";
echo $data->email . "<br>";

foreach ($data->phone as $key => $value) {
    echo $key . "<br>";
    echo $value . "<br>";
}
