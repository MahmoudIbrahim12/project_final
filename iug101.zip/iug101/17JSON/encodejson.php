<?php

header("Content-Type: application/json; charset: utf-8");
// $data = array("Ahmad", "Mohammad", "Ali");
// echo json_encode($data);


// $data = array(1 => "Ahmad", 2 => "Mohammad", 6 => "Ali");
// echo json_encode($data);

// $std = new stdClass;
// $std->name = "Ahmad";
// $std->id = 123;

// echo json_encode($std);

class Emp
{
    public $id;
    public $name;
    public $salary;

    public function __construct($id, $name, $salary)
    {
        $this->id = $id;
        $this->name = $name;
        $this->salary = $salary;
    }
}

$data = array(
    new Emp(1, "Ahmad", 325),
    new Emp(2, "Mohammad", 546),
    new Emp(3, "Alaa", 435)
);

echo json_encode($data);
